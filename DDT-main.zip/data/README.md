# Datasets

We have evaluated FinalMLP on the following preprocessed datasets.

+ [Criteo](./Criteo/Criteo_x1)
+ [Avazu](./Avazu/Avazu_x1)
+ [Frappe](./Frappe/Frappe_x1)
+ [MovieLens](./Movielens/MovielensLatest_x1)

