# pip install fuxictr==2.0.1
import fuxictr
assert fuxictr.__version__ == "2.0.1"
